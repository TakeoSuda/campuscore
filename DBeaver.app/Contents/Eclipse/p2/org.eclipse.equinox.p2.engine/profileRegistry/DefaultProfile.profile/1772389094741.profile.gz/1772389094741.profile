<?xml version='1.0' encoding='UTF-8'?>
<?profile version='1.0.0'?>
<profile id='DefaultProfile' timestamp='1772389094741'>
  <properties size='5'>
    <property name='org.eclipse.equinox.p2.cache' value='/var/jenkins_home/jobs/DBeaverDesktop/jobs/build/workspace/dbeaver/product/community/target/products/org.jkiss.dbeaver.core.product/macosx/cocoa/aarch64/DBeaver.app/Contents/Eclipse'/>
    <property name='org.eclipse.update.install.features' value='true'/>
    <property name='org.eclipse.equinox.p2.roaming' value='true'/>
    <property name='org.eclipse.equinox.p2.environments' value='osgi.os=macosx,osgi.arch=aarch64,osgi.ws=cocoa,osgi.nl=en_US'/>
    <property name='org.eclipse.equinox.p2.installFolder' value='/var/jenkins_home/jobs/DBeaverDesktop/jobs/build/workspace/dbeaver/product/community/target/products/org.jkiss.dbeaver.core.product/macosx/cocoa/aarch64/DBeaver.app/Contents/Eclipse'/>
  </properties>
</profile>
